import { Language } from '../context/LanguageContext';

type TranslationStructure = {
  [key in Language]: {
    nav: {
      home: string;
      products: string;
      about: string;
      contacts: string;
      cart: string;
    };
    hero: {
      title: string;
      subtitle: string;
      cta_products: string;
      cta_order: string;
    };
    features: {
      production: string;
      packaging: string;
      equipment: string;
      quality: string;
      clients: string;
      export: string;
    };
    categories: {
      carbon: string;
      bentonite: string;
      woodchips: string;
      machines: string;
      bags: string;
    };
    products: {
      title: string;
      addToCart: string;
      selectOption: string;
      description: string;
      characteristics: string;
      packaging: string;
    };
    cart: {
      title: string;
      empty: string;
      total: string;
      checkout: string;
      name: string;
      phone: string;
      comment: string;
      sendOrder: string;
      orderSuccess: string;
      orderText: string;
      backToCatalog: string;
    };
    about: {
      title: string;
      text: string;
    };
    contacts: {
      title: string;
      address: string;
      phones: string;
      callBack: string;
      subtitle: string;
    };
    footer: {
      rights: string;
    };
    applications: {
      title: string;
      items: {
        filtration: { title: string; text: string };
        industry: { title: string; text: string };
        food: { title: string; text: string };
        logistics: { title: string; text: string };
      }
    };
  };
};

export const translations: TranslationStructure = {
  ru: {
    nav: {
      home: "Главная",
      products: "Продукция",
      about: "О компании",
      contacts: "Контакты",
      cart: "Корзина",
    },
    hero: {
      title: "ЧП Нестеренко",
      subtitle: "Производство и поставка активированного угля, бентонита, натуральной древесной щепы и решений для упаковки по всему миру.",
      cta_products: "Перейти к продукции",
      cta_order: "Оформить заказ",
    },
    features: {
      production: "Собственное производство",
      packaging: "Любые фасовки и мешки",
      equipment: "Современное оборудование",
      quality: "Контроль качества",
      clients: "Работаем с частными и промышленными клиентами",
      export: "Международные поставки",
    },
    categories: {
      carbon: "Активированный уголь",
      bentonite: "Бентонит",
      woodchips: "Древесная щепа",
      machines: "Швейные машинки",
      bags: "Мешки на заказ",
    },
    products: {
      title: "Каталог продукции",
      addToCart: "В корзину",
      selectOption: "Выберите вариант",
      description: "Описание",
      characteristics: "Характеристики",
      packaging: "Фасовка",
    },
    cart: {
      title: "Ваша корзина",
      empty: "Корзина пуста",
      total: "Итого позиций:",
      checkout: "Оформить заказ",
      name: "Ваше имя",
      phone: "Телефон",
      comment: "Комментарий к заказу",
      sendOrder: "Отправить заказ",
      orderSuccess: "Заказ сформирован! Мы свяжемся с вами в ближайшее время.",
      orderText: "Подтверждаю заказ. Свяжитесь со мной.",
      backToCatalog: "Вернуться в каталог",
    },
    about: {
      title: "О компании",
      text: "ЧП Нестеренко — производственно-торговое предприятие, специализирующееся на поставках активированного угля, бентонита, натуральной древесной щепы и сопутствующих решений для фасовки и упаковки. Мы работаем по Украине и по всему миру, обеспечивая гибкие условия, индивидуальные заказы и современный подход к обслуживанию клиентов.",
    },
    contacts: {
      title: "Контакты и Самовывоз",
      address: "г. Запорожье, ул. Антенная, 16А",
      phones: "Телефоны",
      callBack: "Мы перезвоним вам",
      subtitle: "Свяжитесь с нами для консультации или заказа",
    },
    footer: {
      rights: "© 2024 ЧП Нестеренко. Все права защищены.",
    },
    applications: {
      title: "Для чего нужны наши товары?",
      items: {
        filtration: {
          title: "Очистка и фильтрация",
          text: "Активированный уголь и бентонит применяются для очистки воды, воздуха, масел и промышленных жидкостей."
        },
        industry: {
          title: "Производство и промышленность",
          text: "Используются в химической, пищевой, металлургической и строительной сферах."
        },
        food: {
          title: "Пищевая отрасль",
          text: "Древесная щепа применяется для копчения и ароматизации продуктов, придавая натуральный вкус и аромат."
        },
        logistics: {
          title: "Упаковка и логистика",
          text: "Швейные машинки и мешки обеспечивают надёжную фасовку и транспортировку продукции."
        }
      }
    }
  },
  ua: {
    nav: {
      home: "Головна",
      products: "Продукція",
      about: "Про компанію",
      contacts: "Контакти",
      cart: "Кошик",
    },
    hero: {
      title: "ЧП Нестеренко",
      subtitle: "Виробництво та постачання активованого вугілля, бентоніту, натуральної деревної тріски та рішень для пакування по всьому світу.",
      cta_products: "Перейти до продукції",
      cta_order: "Оформити замовлення",
    },
    features: {
      production: "Власне виробництво",
      packaging: "Будь-які фасування та мішки",
      equipment: "Сучасне обладнання",
      quality: "Контроль якості",
      clients: "Працюємо з приватними та промисловими клієнтами",
      export: "Міжнародні поставки",
    },
    categories: {
      carbon: "Активоване вугілля",
      bentonite: "Бентоніт",
      woodchips: "Деревна тріска",
      machines: "Швейні машинки",
      bags: "Мішки на замовлення",
    },
    products: {
      title: "Каталог продукції",
      addToCart: "У кошик",
      selectOption: "Оберіть варіант",
      description: "Опис",
      characteristics: "Характеристики",
      packaging: "Фасування",
    },
    cart: {
      title: "Ваш кошик",
      empty: "Кошик порожній",
      total: "Разом позицій:",
      checkout: "Оформити замовлення",
      name: "Ваше ім'я",
      phone: "Телефон",
      comment: "Коментар до замовлення",
      sendOrder: "Надіслати замовлення",
      orderSuccess: "Замовлення сформовано! Ми зв'яжемося з вами найближчим часом.",
      orderText: "Підтверджую замовлення. Зв'яжіться зі мною.",
      backToCatalog: "Повернутися до каталогу",
    },
    about: {
      title: "Про компанію",
      text: "ЧП Нестеренко — виробничо-торгове підприємство, що спеціалізується на постачанні активованого вугілля, бентоніту, натуральної деревної тріски та супутніх рішень для фасування та пакування. Ми працюємо по Україні та по всьому світу, забезпечуючи гнучкі умови, індивідуальні замовлення та сучасний підхід до обслуговування клієнтів.",
    },
    contacts: {
      title: "Контакти та Самовивіз",
      address: "м. Запоріжжя, вул. Антенна, 16А",
      phones: "Телефони",
      callBack: "Ми передзвонимо вам",
      subtitle: "Зв'яжіться з нами для консультації або замовлення",
    },
    footer: {
      rights: "© 2024 ЧП Нестеренко. Всі права захищені.",
    },
    applications: {
      title: "Для чого потрібні наші товари?",
      items: {
        filtration: {
          title: "Очищення та фільтрація",
          text: "Активоване вугілля та бентоніт застосовуються для очищення води, повітря, олій та промислових рідин."
        },
        industry: {
          title: "Виробництво та промисловість",
          text: "Використовуються в хімічній, харчовій, металургійній та будівельній сферах."
        },
        food: {
          title: "Харчова галузь",
          text: "Деревна тріска застосовується для копчення та ароматизації продуктів, надаючи натуральний смак та аромат."
        },
        logistics: {
          title: "Упаковка та логістика",
          text: "Швейні машинки та мішки забезпечують надійне фасування та транспортування продукції."
        }
      }
    }
  },
  en: {
    nav: {
      home: "Home",
      products: "Products",
      about: "About Us",
      contacts: "Contacts",
      cart: "Cart",
    },
    hero: {
      title: "Chp Nesterenko",
      subtitle: "Production and supply of activated carbon, bentonite, natural wood chips, and packaging solutions worldwide.",
      cta_products: "View Products",
      cta_order: "Order Now",
    },
    features: {
      production: "Own production",
      packaging: "Any packaging and bags",
      equipment: "Modern equipment",
      quality: "Quality control",
      clients: "Serving private and industrial clients",
      export: "International shipping",
    },
    categories: {
      carbon: "Activated Carbon",
      bentonite: "Bentonite",
      woodchips: "Wood Chips",
      machines: "Sewing Machines",
      bags: "Custom Bags",
    },
    products: {
      title: "Product Catalog",
      addToCart: "Add to Cart",
      selectOption: "Select Option",
      description: "Description",
      characteristics: "Characteristics",
      packaging: "Packaging",
    },
    cart: {
      title: "Your Cart",
      empty: "Your cart is empty",
      total: "Total items:",
      checkout: "Checkout",
      name: "Your Name",
      phone: "Phone",
      comment: "Order Comment",
      sendOrder: "Send Order",
      orderSuccess: "Order placed! We will contact you shortly.",
      orderText: "Confirming order. Please contact me.",
      backToCatalog: "Back to Catalog",
    },
    about: {
      title: "About Us",
      text: "Chp Nesterenko is a production and trading enterprise specializing in the supply of activated carbon, bentonite, natural wood chips, and related packaging solutions. We work across Ukraine and worldwide, ensuring flexible terms, individual orders, and a modern approach to customer service.",
    },
    contacts: {
      title: "Contacts & Pickup",
      address: "Zaporizhzhia, Antennaya St, 16A",
      phones: "Phones",
      callBack: "We will call you back",
      subtitle: "Contact us for consultation or ordering",
    },
    footer: {
      rights: "© 2024 Chp Nesterenko. All rights reserved.",
    },
    applications: {
      title: "Why do you need our products?",
      items: {
        filtration: {
          title: "Cleaning & Filtration",
          text: "Activated carbon and bentonite are used for purification of water, air, oils, and industrial liquids."
        },
        industry: {
          title: "Production & Industry",
          text: "Used in chemical, food, metallurgical, and construction sectors."
        },
        food: {
          title: "Food Industry",
          text: "Wood chips are used for smoking and flavoring products, giving natural taste and aroma."
        },
        logistics: {
          title: "Packaging & Logistics",
          text: "Sewing machines and bags ensure reliable packaging and transportation of products."
        }
      }
    }
  },
};

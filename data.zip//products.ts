import { ProductOption } from './products'; // Keeping type import convention, though we rewrite file

export interface ProductOption {
  id: string;
  name: {
    ru: string;
    ua: string;
    en: string;
  };
}

export interface Product {
  id: string;
  category: 'carbon' | 'bentonite' | 'woodchips' | 'machines' | 'bags';
  name: {
    ru: string;
    ua: string;
    en: string;
  };
  description: {
    ru: string;
    ua: string;
    en: string;
  };
  features: {
    ru: string[];
    ua: string[];
    en: string[];
  };
  options: ProductOption[];
  image: string;
}

export const products: Product[] = [
  {
    id: 'carbon-gran',
    category: 'carbon',
    name: {
      ru: 'Уголь Активированный Гранулированный',
      ua: 'Вугілля Активоване Гранульоване',
      en: 'Granular Activated Carbon',
    },
    description: {
      ru: 'Высокоэффективный гранулированный уголь для фильтров, очистки воды и сточных вод.',
      ua: 'Високоефективне гранульоване вугілля для фільтрів, очищення води та стічних вод.',
      en: 'High-efficiency granular carbon for filters, water and wastewater purification.',
    },
    features: {
      ru: ['Высокая сорбция', 'Стабильное качество', 'Различные фракции'],
      ua: ['Висока сорбція', 'Стабільна якість', 'Різні фракції'],
      en: ['High sorption', 'Stable quality', 'Various fractions'],
    },
    options: [
      { id: '25kg', name: { ru: '25 кг', ua: '25 кг', en: '25 kg' } },
      { id: '50kg', name: { ru: '50 кг', ua: '50 кг', en: '50 kg' } },
    ],
    image: 'https://images.unsplash.com/photo-1672487914859-5ef8d8c7f8f1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxncmFudWxhciUyMGFjdGl2YXRlZCUyMGNhcmJvbiUyMGNsb3NlJTIwdXB8ZW58MXx8fHwxNzY1NzE2NzU3fDA&ixlib=rb-4.1.0&q=80&w=1080',
  },
  {
    id: 'carbon-pow',
    category: 'carbon',
    name: {
      ru: 'Уголь Активированный Порошковый',
      ua: 'Вугілля Активоване Порошкове',
      en: 'Powdered Activated Carbon',
    },
    description: {
      ru: 'Порошковый уголь для осветления жидкостей, очистки масел и химической промышленности.',
      ua: 'Порошкове вугілля для освітлення рідин, очищення олій та хімічної промисловості.',
      en: 'Powdered carbon for liquid clarification, oil purification, and chemical industry.',
    },
    features: {
      ru: ['Мгновенное действие', 'Тонкая очистка', 'Пищевое качество'],
      ua: ['Миттєва дія', 'Тонке очищення', 'Харчова якість'],
      en: ['Instant action', 'Fine purification', 'Food grade'],
    },
    options: [
      { id: '10kg', name: { ru: '10 кг', ua: '10 кг', en: '10 kg' } },
      { id: '25kg', name: { ru: '25 кг', ua: '25 кг', en: '25 kg' } },
    ],
    image: 'https://images.unsplash.com/photo-1602834281510-61f8cee7ddf6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhY3RpdmF0ZWQlMjBjYXJib24lMjBjaGFyY29hbCUyMHBpbGUlMjBibGFja3xlbnwxfHx8fDE3NjU3MTYxMDV8MA&ixlib=rb-4.1.0&q=80&w=1080',
  },
  {
    id: 'carbon-lump',
    category: 'carbon',
    name: {
      ru: 'Уголь Активированный Кусковой / Технический',
      ua: 'Вугілля Активоване Кускове / Технічне',
      en: 'Lump / Technical Activated Carbon',
    },
    description: {
      ru: 'Крупнофракционный уголь для промышленных фильтров и технологических процессов.',
      ua: 'Великофракційне вугілля для промислових фільтрів та технологічних процесів.',
      en: 'Large fraction carbon for industrial filters and technological processes.',
    },
    features: {
      ru: ['Промышленное применение', 'Высокий ресурс', 'Фильтрация газов'],
      ua: ['Промислове застосування', 'Високий ресурс', 'Фільтрація газів'],
      en: ['Industrial application', 'High durability', 'Gas filtration'],
    },
    options: [
      { id: '25kg', name: { ru: '25 кг', ua: '25 кг', en: '25 kg' } },
      { id: 'bulk', name: { ru: 'Опт от 500кг', ua: 'Опт від 500кг', en: 'Bulk from 500kg' } },
    ],
    image: 'https://images.unsplash.com/photo-1602834281510-61f8cee7ddf6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhY3RpdmF0ZWQlMjBjYXJib24lMjBjaGFyY29hbCUyMHBpbGUlMjBibGFja3xlbnwxfHx8fDE3NjU3MTYxMDV8MA&ixlib=rb-4.1.0&q=80&w=1080',
  },
  {
    id: 'bentonite-ind',
    category: 'bentonite',
    name: {
      ru: 'Бентонит Промышленный / Технический',
      ua: 'Бентоніт Промисловий / Технічний',
      en: 'Industrial / Technical Bentonite',
    },
    description: {
      ru: 'Натуральный бентонит для очистки жидкостей, металлургии и сельского хозяйства.',
      ua: 'Натуральний бентоніт для очищення рідин, металургії та сільського господарства.',
      en: 'Natural bentonite for liquid purification, metallurgy, and agriculture.',
    },
    features: {
      ru: ['Высокая степень очистки', 'Отличная вязкость', 'Натуральный'],
      ua: ['Високий ступінь очищення', 'Відмінна в\'язкість', 'Натуральний'],
      en: ['High purity', 'Excellent viscosity', 'Natural'],
    },
    options: [
      { id: '25kg', name: { ru: 'Мешок 25 кг', ua: 'Мішок 25 кг', en: 'Bag 25 kg' } },
      { id: 'bulk', name: { ru: 'Биг-Бэг 1т', ua: 'Біг-Бег 1т', en: 'Big-Bag 1t' } },
    ],
    image: 'https://images.unsplash.com/photo-1665914783067-011756db27eb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiZW50b25pdGUlMjBjbGF5JTIwcG93ZGVyJTIwaW5kdXN0cmlhbHxlbnwxfHx8fDE3NjU3MTYxMDV8MA&ixlib=rb-4.1.0&q=80&w=1080',
  },
  {
    id: 'bentonite-const',
    category: 'bentonite',
    name: {
      ru: 'Бентонит Строительный / Для бурения',
      ua: 'Бентоніт Будівельний / Для буріння',
      en: 'Construction / Drilling Bentonite',
    },
    description: {
      ru: 'Для гидроизоляции, буровых растворов и строительных смесей.',
      ua: 'Для гідроізоляції, бурових розчинів та будівельних сумішей.',
      en: 'For waterproofing, drilling fluids, and construction mixtures.',
    },
    features: {
      ru: ['Образование корки', 'Пластичность', 'Стабильная фракция'],
      ua: ['Утворення кірки', 'Пластичність', 'Стабільна фракція'],
      en: ['Filter cake formation', 'Plasticity', 'Stable fraction'],
    },
    options: [
      { id: '25kg', name: { ru: 'Мешок 25 кг', ua: 'Мішок 25 кг', en: 'Bag 25 kg' } },
    ],
    image: 'https://images.unsplash.com/photo-1631801754345-8b998163dc1d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiZW50b25pdGUlMjBkcmlsbGluZyUyMG11ZCUyMGRyaWxsaW5nJTIwcmlnfGVufDF8fHx8MTc2NTcxNjc1N3ww&ixlib=rb-4.1.0&q=80&w=1080',
  },
  {
    id: 'chips-oak',
    category: 'woodchips',
    name: {
      ru: 'Щепа Дубовая',
      ua: 'Тріска Дубова',
      en: 'Oak Wood Chips',
    },
    description: {
      ru: 'Для копчения мяса и сыров, ароматизации и пищевой промышленности.',
      ua: 'Для копчення м\'яса та сирів, ароматизації та харчової промисловості.',
      en: 'For smoking meat and cheese, flavoring, and food industry.',
    },
    features: {
      ru: ['Без химии', 'Насыщенный вкус', 'Любая фракция'],
      ua: ['Без хімії', 'Насичений смак', 'Будь-яка фракція'],
      en: ['No chemicals', 'Rich taste', 'Any fraction'],
    },
    options: [
      { id: 'small', name: { ru: 'Мелкая', ua: 'Дрібна', en: 'Small' } },
      { id: 'medium', name: { ru: 'Средняя', ua: 'Середня', en: 'Medium' } },
      { id: 'large', name: { ru: 'Крупная', ua: 'Велика', en: 'Large' } },
    ],
    image: 'https://images.unsplash.com/photo-1613029799604-b340c7466c8e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3b29kJTIwY2hpcHMlMjBzbW9raW5nJTIwYmJxJTIwb2FrJTIwY2hlcnJ5fGVufDF8fHx8MTc2NTcxNjEwNXww&ixlib=rb-4.1.0&q=80&w=1080',
  },
  {
    id: 'chips-cherry',
    category: 'woodchips',
    name: {
      ru: 'Щепа Вишневая',
      ua: 'Тріска Вишнева',
      en: 'Cherry Wood Chips',
    },
    description: {
      ru: 'Ароматная щепа для изысканного копчения, придает красноватый оттенок.',
      ua: 'Ароматна тріска для вишуканого копчення, надає червонуватий відтінок.',
      en: 'Aromatic chips for exquisite smoking, gives a reddish tint.',
    },
    features: {
      ru: ['Фруктовый аромат', 'Натуральный цвет', 'Без коры'],
      ua: ['Фруктовий аромат', 'Натуральний колір', 'Без кори'],
      en: ['Fruity aroma', 'Natural color', 'Bark free'],
    },
    options: [
      { id: 'std', name: { ru: 'Микс фракций', ua: 'Мікс фракцій', en: 'Mixed fractions' } },
    ],
    image: 'https://images.unsplash.com/photo-1613029799604-b340c7466c8e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3b29kJTIwY2hpcHMlMjBzbW9raW5nJTIwYmJxJTIwb2FrJTIwY2hlcnJ5fGVufDF8fHx8MTc2NTcxNjEwNXww&ixlib=rb-4.1.0&q=80&w=1080',
  },
  {
    id: 'chips-pear',
    category: 'woodchips',
    name: {
      ru: 'Щепа Грушевая',
      ua: 'Тріска Грушева',
      en: 'Pear Wood Chips',
    },
    description: {
      ru: 'Мягкий аромат груши, идеален для птицы и рыбы.',
      ua: 'М\'який аромат груші, ідеальний для птиці та риби.',
      en: 'Soft pear aroma, ideal for poultry and fish.',
    },
    features: {
      ru: ['Сладковатый дым', 'Нежный цвет', 'Премиум'],
      ua: ['Солодкуватий дим', 'Ніжний колір', 'Преміум'],
      en: ['Sweet smoke', 'Gentle color', 'Premium'],
    },
    options: [
      { id: 'std', name: { ru: 'Стандарт', ua: 'Стандарт', en: 'Standard' } },
    ],
    image: 'https://images.unsplash.com/photo-1731613705516-db1f5e257202?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwZWFyJTIwd29vZCUyMGNoaXBzJTIwc21va2luZ3xlbnwxfHx8fDE3NjU3MTY3NTd8MA&ixlib=rb-4.1.0&q=80&w=1080',
  },
  {
    id: 'machine-modern',
    category: 'machines',
    name: {
      ru: 'Машинка мешкозашивочная Modern',
      ua: 'Машинка мішкозашивальна Modern',
      en: 'Modern Bag Closing Machine',
    },
    description: {
      ru: 'Современная промышленная машинка: высокая скорость, надежность, современный дизайн.',
      ua: 'Сучасна промислова машинка: висока швидкість, надійність, сучасний дизайн.',
      en: 'Modern industrial machine: high speed, reliability, modern design.',
    },
    features: {
      ru: ['Для всех мешков', 'Интенсивная работа', 'Надежность'],
      ua: ['Для всіх ��ішків', 'Інтенсивна робота', 'Надійність'],
      en: ['For all bags', 'Intensive use', 'Reliability'],
    },
    options: [
      { id: 'unit', name: { ru: '1 шт', ua: '1 шт', en: '1 unit' } },
    ],
    image: 'https://images.unsplash.com/photo-1601390099681-4dbb71411b19?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBoYW5kaGVsZCUyMGluZHVzdHJpYWwlMjBiYWclMjBjbG9zaW5nJTIwc2V3aW5nJTIwbWFjaGluZXxlbnwxfHx8fDE3NjU3MTY3NTh8MA&ixlib=rb-4.1.0&q=80&w=1080',
  },
  {
    id: 'bags-custom',
    category: 'bags',
    name: {
      ru: 'Мешки на заказ',
      ua: 'Мішки на замовлення',
      en: 'Custom Bags',
    },
    description: {
      ru: 'Изготовление мешков под индивидуальные требования. Для угля, бентонита, щепы.',
      ua: 'Виготовлення мішків під індивідуальні вимоги. Для вугілля, бентоніту, тріски.',
      en: 'Custom bag manufacturing. For carbon, bentonite, chips.',
    },
    features: {
      ru: ['Цена: 500 грн/шт', 'Мин. заказ: 1 шт', 'Любая плотность'],
      ua: ['Ціна: 500 грн/шт', 'Мін. замовлення: 1 шт', 'Будь-яка щільність'],
      en: ['Price: 500 UAH/pc', 'Min order: 1 pc', 'Any density'],
    },
    options: [
      { id: 'unit', name: { ru: '1 шт (500 грн)', ua: '1 шт (500 грн)', en: '1 unit (500 UAH)' } },
      { id: 'bulk', name: { ru: 'Опт (договорная)', ua: 'Опт (договірна)', en: 'Bulk (negotiable)' } },
    ],
    image: 'https://images.unsplash.com/photo-1637251393438-30eca8828253?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmR1c3RyaWFsJTIwcG9seXByb3B5bGVuZSUyMGJhZ3MlMjBzdGFja3xlbnwxfHx8fDE3NjU3MTY3NTd8MA&ixlib=rb-4.1.0&q=80&w=1080',
  }
];

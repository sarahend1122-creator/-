import React from 'react';
import { useLanguage } from '../context/LanguageContext';
import { useCart } from '../context/CartContext';
import { Link } from 'react-router-dom';
import { ArrowRight, CheckCircle2, Factory, Truck, Globe2, PackageOpen, Phone, Lightbulb, PenTool, Sprout, Hammer, ShoppingBag, Filter, Utensils } from 'lucide-react';
import { motion } from 'motion/react';
import { Button } from '../components/ui/button';
import { products } from '../data/products';
import { translations } from '../data/translations';

export const Home = () => {
  const { t, language } = useLanguage();
  
  // Get one image for each category for the grid
  const categories = [
    { id: 'carbon', name: t('categories.carbon'), img: products.find(p => p.category === 'carbon')?.image },
    { id: 'bentonite', name: t('categories.bentonite'), img: products.find(p => p.category === 'bentonite')?.image },
    { id: 'woodchips', name: t('categories.woodchips'), img: products.find(p => p.category === 'woodchips')?.image },
    { id: 'machines', name: t('categories.machines'), img: products.find(p => p.category === 'machines')?.image },
    { id: 'bags', name: t('categories.bags'), img: products.find(p => p.category === 'bags')?.image },
  ];

  const appIcons = {
    filtration: Filter,
    industry: Factory,
    food: Utensils,
    logistics: Truck
  };

  return (
    <div>
      {/* Hero Section */}
      <section className="relative h-[80vh] min-h-[600px] flex items-center justify-center overflow-hidden bg-slate-900">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1759272548470-d0686d071036?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmR1c3RyaWFsJTIwd2FyZWhvdXNlJTIwbG9naXN0aWNzJTIwc2hpcHBpbmclMjBjb250YWluZXJ8ZW58MXx8fHwxNzY1NzE2MTA1fDA&ixlib=rb-4.1.0&q=80&w=1080" 
            alt="Warehouse Industrial" 
            className="w-full h-full object-cover opacity-40"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/50 to-transparent" />
        </div>

        <div className="relative z-10 container mx-auto px-4 text-center">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="text-4xl md:text-6xl font-bold text-white mb-6 uppercase tracking-tight"
          >
            {language === 'en' ? 'Chp Nesterenko' : language === 'ua' ? 'ЧП Нестеренко' : 'ЧП Нестеренко'}
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-lg md:text-2xl text-slate-200 max-w-3xl mx-auto mb-10 leading-relaxed font-light"
          >
            {t('hero.subtitle')}
          </motion.p>
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="flex flex-col sm:flex-row gap-4 justify-center"
          >
            <Link to="/products">
              <Button size="lg" className="bg-emerald-600 hover:bg-emerald-700 text-white min-w-[200px] text-lg h-14">
                {t('hero.cta_products')}
              </Button>
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Advantages */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 lg:gap-12">
            {[
              { icon: Factory, title: t('features.production'), text: t('features.equipment') },
              { icon: PackageOpen, title: t('features.packaging'), text: t('features.quality') },
              { icon: Globe2, title: t('features.export'), text: t('features.clients') },
            ].map((feature, idx) => (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
                viewport={{ once: true }}
                className="flex flex-col items-center text-center p-6 border border-slate-100 rounded-xl hover:shadow-lg transition-shadow"
              >
                <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mb-6 text-emerald-700">
                  <feature.icon className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-3">{feature.title}</h3>
                <p className="text-slate-600">{feature.text}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Categories Grid */}
      <section className="py-20 bg-slate-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-slate-900">{t('nav.products')}</h2>
          <div className="flex flex-wrap justify-center gap-6">
            {categories.map((cat, idx) => (
              <Link to="/products" key={cat.id} className="group block relative overflow-hidden rounded-xl w-full sm:w-[calc(50%-12px)] lg:w-[calc(25%-18px)] aspect-[4/5] shadow-sm hover:shadow-xl transition-all">
                <div className="absolute inset-0 bg-slate-900/20 group-hover:bg-slate-900/10 transition-colors z-10" />
                <img 
                  src={cat.img} 
                  alt={cat.name} 
                  className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-700"
                />
                <div className="absolute inset-0 z-20 flex flex-col justify-end p-6 bg-gradient-to-t from-slate-900/90 to-transparent">
                  <h3 className="text-xl font-bold text-white mb-2">{cat.name}</h3>
                  <div className="flex items-center text-emerald-400 text-sm font-medium opacity-0 group-hover:opacity-100 transform translate-y-4 group-hover:translate-y-0 transition-all">
                    <span>Details</span>
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* About Brief */}
      <section id="about" className="py-20 bg-slate-900 text-white">
        <div className="container mx-auto px-4 grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl font-bold mb-6 text-emerald-400">{t('about.title')}</h2>
            <p className="text-lg leading-relaxed text-slate-300 mb-8">
              {t('about.text')}
            </p>
            <ul className="space-y-4">
              {[t('features.production'), t('features.export'), t('features.quality')].map((item, i) => (
                 <li key={i} className="flex items-center gap-3">
                   <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                   <span>{item}</span>
                 </li>
              ))}
            </ul>
          </div>
          <div className="h-[400px] bg-slate-800 rounded-lg overflow-hidden relative">
             <img 
               src="https://images.unsplash.com/photo-1759272548470-d0686d071036?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxpbmR1c3RyaWFsJTIwd2FyZWhvdXNlJTIwbG9naXN0aWNzJTIwc2hpcHBpbmclMjBjb250YWluZXJ8ZW58MXx8fHwxNzY1NzE2MTA1fDA&ixlib=rb-4.1.0&q=80&w=1080"
               alt="Global Logistics" 
               className="w-full h-full object-cover opacity-80"
             />
          </div>
        </div>
      </section>

      {/* Applications Section */}
      <section className="py-20 bg-emerald-50/50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-slate-900">{t('applications.title')}</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-7xl mx-auto">
            {Object.keys(translations[language].applications.items).map((key) => {
              // @ts-ignore
              const { title, text } = translations[language].applications.items[key];
              // @ts-ignore
              const Icon = appIcons[key] || Lightbulb;

              return (
                <div key={key} className="bg-white p-6 rounded-xl shadow-sm border border-emerald-100/50 hover:border-emerald-200 transition-colors h-full flex flex-col">
                  <div className="w-12 h-12 bg-emerald-100 rounded-lg flex items-center justify-center mb-4 text-emerald-700 shrink-0">
                    <Icon className="w-6 h-6" />
                  </div>
                  <h3 className="font-bold text-lg mb-3 text-slate-900">{title}</h3>
                  <p className="text-slate-600 leading-relaxed text-sm flex-grow">
                    {text}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Contacts Brief */}
      <section id="contacts" className="py-20 bg-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4 text-slate-900">{t('contacts.title')}</h2>
          <p className="text-slate-500 mb-12">{t('contacts.subtitle')}</p>
          
          <div className="flex flex-wrap justify-center gap-8 md:gap-16">
            <div className="flex flex-col items-center">
              <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mb-4 text-emerald-700">
                <Globe2 className="w-8 h-8" />
              </div>
              <h4 className="font-bold text-lg mb-2">Address</h4>
              <p className="text-slate-600 max-w-xs">{t('contacts.address')}</p>
            </div>
            <div className="flex flex-col items-center">
              <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mb-4 text-emerald-700">
                <Phone className="w-8 h-8" />
              </div>
              <h4 className="font-bold text-lg mb-2">Phones</h4>
              <p className="text-slate-600 font-mono">+38 (095) 908-28-49</p>
              <p className="text-slate-600 font-mono">+38 (066) 477-96-61</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

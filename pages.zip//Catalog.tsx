import React, { useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import { useCart } from '../context/CartContext';
import { products, Product } from '../data/products';
import { Button } from '../components/ui/button';
import { Plus, Check } from 'lucide-react';
import { toast } from 'sonner@2.0.3';

export const Catalog = () => {
  const { t, language } = useLanguage();
  const { addToCart } = useCart();
  
  const [selectedOptions, setSelectedOptions] = useState<Record<string, string>>({});

  const handleOptionChange = (productId: string, optionId: string) => {
    setSelectedOptions(prev => ({ ...prev, [productId]: optionId }));
  };

  const handleAddToCart = (product: Product) => {
    const optionId = selectedOptions[product.id] || product.options[0].id;
    const option = product.options.find(o => o.id === optionId);
    
    if (option) {
      addToCart(product, option, 1);
      toast.success(`${product.name[language]} (${option.name[language]}) added to cart`);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 py-12">
      <div className="container mx-auto px-4">
        <h1 className="text-3xl md:text-4xl font-bold text-slate-900 mb-8">{t('products.title')}</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {products.map((product) => {
             const currentOptionId = selectedOptions[product.id] || product.options[0].id;

             return (
              <div key={product.id} className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden flex flex-col">
                <div className="aspect-[4/3] bg-slate-200 relative">
                  <img 
                    src={product.image} 
                    alt={product.name[language]} 
                    className="w-full h-full object-cover"
                  />
                </div>
                
                <div className="p-6 flex flex-col flex-grow">
                  <div className="mb-4">
                    <span className="text-xs font-bold text-emerald-600 uppercase tracking-wide">
                      {t(`categories.${product.category}`)}
                    </span>
                    <h3 className="text-xl font-bold text-slate-900 mt-1">{product.name[language]}</h3>
                  </div>
                  
                  <p className="text-slate-600 text-sm mb-6 flex-grow">
                    {product.description[language]}
                  </p>

                  <div className="mb-6">
                    <h4 className="text-sm font-semibold text-slate-900 mb-2">{t('products.characteristics')}:</h4>
                    <ul className="text-sm text-slate-600 space-y-1">
                      {product.features[language].map((feature, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <span className="w-1 h-1 rounded-full bg-emerald-500 mt-2 shrink-0" />
                          {feature}
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="mt-auto pt-6 border-t border-slate-100">
                    <div className="mb-4">
                       <label className="text-xs font-medium text-slate-500 block mb-2">{t('products.packaging')}:</label>
                       <div className="flex flex-wrap gap-2">
                         {product.options.map(opt => (
                           <button
                             key={opt.id}
                             onClick={() => handleOptionChange(product.id, opt.id)}
                             className={`px-3 py-1.5 text-xs rounded-md border transition-all ${
                               currentOptionId === opt.id
                                 ? 'bg-emerald-50 border-emerald-500 text-emerald-700 font-medium'
                                 : 'bg-white border-slate-200 text-slate-600 hover:border-slate-300'
                             }`}
                           >
                             {opt.name[language]}
                           </button>
                         ))}
                       </div>
                    </div>

                    <Button 
                      onClick={() => handleAddToCart(product)}
                      className="w-full bg-slate-900 hover:bg-slate-800"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      {t('products.addToCart')}
                    </Button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

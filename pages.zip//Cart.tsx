import React, { useState } from 'react';
import { useCart } from '../context/CartContext';
import { useLanguage } from '../context/LanguageContext';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Textarea } from '../components/ui/textarea';
import { Trash2, ShoppingBag, Send } from 'lucide-react';
import { Link } from 'react-router-dom';

export const Cart = () => {
  const { items, removeFromCart, clearCart, totalItems } = useCart();
  const { t, language } = useLanguage();
  
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    comment: ''
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleCheckout = () => {
    // Construct message for WhatsApp/Direct Communication
    let message = `*${t('hero.title')} - New Order*\n\n`;
    message += `*Customer:* ${formData.name}\n`;
    message += `*Phone:* ${formData.phone}\n`;
    if (formData.comment) message += `*Comment:* ${formData.comment}\n`;
    message += `\n*Order Details:*\n`;
    
    items.forEach((item, idx) => {
      message += `${idx + 1}. ${item.product.name[language]} [${item.selectedOption.name[language]}] x ${item.quantity}\n`;
    });

    const encodedMessage = encodeURIComponent(message);
    const whatsappUrl = `https://wa.me/380959082849?text=${encodedMessage}`;
    
    // Open WhatsApp
    window.open(whatsappUrl, '_blank');
    
    // Optional: Clear cart or show success modal
    // clearCart(); 
  };

  if (items.length === 0) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center p-4">
        <div className="w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center mb-6 text-slate-400">
          <ShoppingBag className="w-10 h-10" />
        </div>
        <h2 className="text-2xl font-bold text-slate-900 mb-2">{t('cart.empty')}</h2>
        <Link to="/products">
          <Button variant="outline" className="mt-4">
            {t('cart.backToCatalog')}
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 py-12">
      <div className="container mx-auto px-4 max-w-4xl">
        <h1 className="text-3xl font-bold text-slate-900 mb-8">{t('cart.title')}</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Cart Items List */}
          <div className="md:col-span-2 space-y-4">
            {items.map((item) => (
              <div key={`${item.productId}-${item.optionId}`} className="bg-white p-4 rounded-lg shadow-sm border border-slate-100 flex gap-4 items-center">
                <div className="w-20 h-20 bg-slate-100 rounded-md overflow-hidden shrink-0">
                  <img src={item.product.image} alt="" className="w-full h-full object-cover" />
                </div>
                <div className="flex-grow">
                  <h3 className="font-bold text-slate-900">{item.product.name[language]}</h3>
                  <p className="text-sm text-slate-500">{t('products.packaging')}: {item.selectedOption.name[language]}</p>
                  <p className="text-sm font-medium mt-1">Qty: {item.quantity}</p>
                </div>
                <button 
                  onClick={() => removeFromCart(item.productId, item.optionId)}
                  className="p-2 text-red-500 hover:bg-red-50 rounded-full transition-colors"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              </div>
            ))}
          </div>

          {/* Checkout Form */}
          <div className="md:col-span-1">
            <div className="bg-white p-6 rounded-lg shadow-sm border border-slate-100 sticky top-24">
              <h3 className="font-bold text-lg mb-4">{t('cart.checkout')}</h3>
              
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium mb-1 block">{t('cart.name')}</label>
                  <Input 
                    name="name" 
                    value={formData.name} 
                    onChange={handleInputChange} 
                    placeholder="John Doe" 
                  />
                </div>
                <div>
                  <label className="text-sm font-medium mb-1 block">{t('cart.phone')}</label>
                  <Input 
                    name="phone" 
                    value={formData.phone} 
                    onChange={handleInputChange} 
                    placeholder="+38 (000) 000-00-00" 
                  />
                </div>
                <div>
                  <label className="text-sm font-medium mb-1 block">{t('cart.comment')}</label>
                  <Textarea 
                    name="comment" 
                    value={formData.comment} 
                    onChange={handleInputChange} 
                    placeholder="..." 
                    className="resize-none"
                  />
                </div>

                <div className="pt-4 border-t border-slate-100">
                  <div className="flex justify-between mb-4 font-bold text-slate-900">
                    <span>{t('cart.total')}</span>
                    <span>{totalItems}</span>
                  </div>
                  
                  <Button 
                    className="w-full bg-emerald-600 hover:bg-emerald-700" 
                    size="lg"
                    onClick={handleCheckout}
                    disabled={!formData.name || !formData.phone}
                  >
                    <Send className="w-4 h-4 mr-2" />
                    {t('cart.sendOrder')}
                  </Button>
                  <p className="text-xs text-center text-slate-400 mt-2">
                    Orders are sent via WhatsApp/Messenger directly to our manager.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

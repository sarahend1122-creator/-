import React from 'react';
import { useLanguage } from '../context/LanguageContext';
import { useCart } from '../context/CartContext';
import { Link } from 'react-router-dom';
import { ShoppingCart, Menu, X, Phone, Globe } from 'lucide-react';
import { Button } from './ui/button';
import { Sheet, SheetContent, SheetTrigger } from './ui/sheet';

export const Layout = ({ children }: { children: React.ReactNode }) => {
  const { t, language, setLanguage } = useLanguage();
  const { totalItems } = useCart();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);

  const navLinks = [
    { name: t('nav.home'), path: '/' },
    { name: t('nav.products'), path: '/products' },
    { name: t('nav.about'), path: '/#about' }, // Anchor for single page feel or route
    { name: t('nav.contacts'), path: '/#contacts' },
  ];

  const languages: { code: 'ru' | 'ua' | 'en'; label: string }[] = [
    { code: 'ru', label: 'RU' },
    { code: 'ua', label: 'UA' },
    { code: 'en', label: 'EN' },
  ];

  const siteName = language === 'en' ? 'Chp Nesterenko' : 'ЧП Нестеренко';

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 font-sans text-slate-900">
      {/* Top Bar - Contact Info */}
      <div className="bg-slate-900 text-slate-300 py-2 px-4 text-xs md:text-sm">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <span className="flex items-center gap-1">
              <Phone className="w-3 h-3" /> +38 (095) 908-28-49
            </span>
            <span className="hidden md:flex items-center gap-1">
               | +38 (066) 477-96-61
            </span>
          </div>
          <div className="flex items-center gap-2">
            <span>Worldwide Shipping</span>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <header className="sticky top-0 z-50 bg-white/95 backdrop-blur shadow-sm border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <Link to="/" className="flex flex-col">
              <span className="text-xl font-bold tracking-tight text-slate-900 uppercase">
                {siteName}
              </span>
              <span className="text-[10px] text-emerald-700 tracking-wider font-medium">
                PRODUCTION & SUPPLY
              </span>
            </Link>

            {/* Desktop Nav */}
            <nav className="hidden md:flex items-center space-x-8">
              {navLinks.map((link) => (
                <Link
                  key={link.name}
                  to={link.path}
                  className="text-sm font-medium text-slate-600 hover:text-emerald-700 transition-colors"
                >
                  {link.name}
                </Link>
              ))}
            </nav>

            {/* Actions */}
            <div className="flex items-center space-x-4">
              {/* Language Switcher */}
              <div className="hidden md:flex items-center gap-1 bg-slate-100 rounded-full p-1">
                {languages.map((lang) => (
                  <button
                    key={lang.code}
                    onClick={() => setLanguage(lang.code)}
                    className={`px-2 py-1 text-xs font-bold rounded-full transition-all ${
                      language === lang.code
                        ? 'bg-white text-emerald-800 shadow-sm'
                        : 'text-slate-500 hover:text-slate-700'
                    }`}
                  >
                    {lang.label}
                  </button>
                ))}
              </div>

              {/* Cart */}
              <Link to="/cart" className="relative p-2 text-slate-600 hover:text-emerald-700 transition-colors">
                <ShoppingCart className="w-6 h-6" />
                {totalItems > 0 && (
                  <span className="absolute top-0 right-0 inline-flex items-center justify-center px-1.5 py-0.5 text-xs font-bold leading-none text-white transform translate-x-1/4 -translate-y-1/4 bg-emerald-600 rounded-full">
                    {totalItems}
                  </span>
                )}
              </Link>

              {/* Mobile Menu Button */}
              <div className="md:hidden">
                 <Sheet open={isMobileMenuOpen} onOpenChange={setIsMobileMenuOpen}>
                  <SheetTrigger asChild>
                    <Button variant="ghost" size="icon">
                      <Menu className="w-6 h-6" />
                    </Button>
                  </SheetTrigger>
                  <SheetContent side="right">
                    <div className="flex flex-col gap-6 mt-6">
                      {navLinks.map((link) => (
                        <Link
                          key={link.name}
                          to={link.path}
                          onClick={() => setIsMobileMenuOpen(false)}
                          className="text-lg font-medium text-slate-900"
                        >
                          {link.name}
                        </Link>
                      ))}
                      <div className="h-px bg-slate-200" />
                      <div className="flex gap-2 justify-center">
                         {languages.map((lang) => (
                          <button
                            key={lang.code}
                            onClick={() => {
                              setLanguage(lang.code);
                              setIsMobileMenuOpen(false);
                            }}
                            className={`px-3 py-2 text-sm font-bold rounded-md border ${
                              language === lang.code
                                ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                                : 'border-slate-200 text-slate-500'
                            }`}
                          >
                            {lang.label}
                          </button>
                        ))}
                      </div>
                    </div>
                  </SheetContent>
                </Sheet>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-grow">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-400 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-white text-lg font-bold mb-4">
                {siteName}
              </h3>
              <p className="text-sm leading-relaxed max-w-xs">
                {t('hero.subtitle')}
              </p>
            </div>
            <div>
              <h3 className="text-white text-lg font-bold mb-4">{t('nav.products')}</h3>
              <ul className="space-y-2 text-sm">
                <li><Link to="/products" className="hover:text-emerald-400 transition-colors">{t('categories.carbon')}</Link></li>
                <li><Link to="/products" className="hover:text-emerald-400 transition-colors">{t('categories.bentonite')}</Link></li>
                <li><Link to="/products" className="hover:text-emerald-400 transition-colors">{t('categories.woodchips')}</Link></li>
                <li><Link to="/products" className="hover:text-emerald-400 transition-colors">{t('categories.machines')}</Link></li>
                <li><Link to="/products" className="hover:text-emerald-400 transition-colors">{t('categories.bags')}</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="text-white text-lg font-bold mb-4">{t('contacts.title')}</h3>
              <ul className="space-y-3 text-sm">
                <li className="flex items-start gap-3">
                  <Globe className="w-5 h-5 text-emerald-500 shrink-0" />
                  <span>{t('contacts.address')}</span>
                </li>
                <li className="flex items-start gap-3">
                  <Phone className="w-5 h-5 text-emerald-500 shrink-0" />
                  <div className="flex flex-col">
                    <span>+38 (095) 908-28-49</span>
                    <span>+38 (066) 477-96-61</span>
                  </div>
                </li>
              </ul>
            </div>
          </div>
          <div className="mt-12 pt-8 border-t border-slate-800 text-center text-xs">
            {t('footer.rights')}
          </div>
        </div>
      </footer>
    </div>
  );
};

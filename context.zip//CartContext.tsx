import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Product, ProductOption } from '../data/products';

export interface CartItem {
  productId: string;
  optionId: string;
  quantity: number;
  product: Product; // Full product reference for ease
  selectedOption: ProductOption;
}

interface CartContextType {
  items: CartItem[];
  addToCart: (product: Product, option: ProductOption, quantity: number) => void;
  removeFromCart: (productId: string, optionId: string) => void;
  clearCart: () => void;
  totalItems: number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};

export const CartProvider = ({ children }: { children: ReactNode }) => {
  const [items, setItems] = useState<CartItem[]>([]);

  // Load from local storage
  useEffect(() => {
    const savedCart = localStorage.getItem('nesterenko-cart');
    if (savedCart) {
      try {
        setItems(JSON.parse(savedCart));
      } catch (e) {
        console.error("Failed to parse cart", e);
      }
    }
  }, []);

  // Save to local storage
  useEffect(() => {
    localStorage.setItem('nesterenko-cart', JSON.stringify(items));
  }, [items]);

  const addToCart = (product: Product, option: ProductOption, quantity: number) => {
    setItems((prev) => {
      const existing = prev.find(
        (item) => item.productId === product.id && item.optionId === option.id
      );
      if (existing) {
        return prev.map((item) =>
          item.productId === product.id && item.optionId === option.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [...prev, { productId: product.id, optionId: option.id, quantity, product, selectedOption: option }];
    });
  };

  const removeFromCart = (productId: string, optionId: string) => {
    setItems((prev) => prev.filter((item) => !(item.productId === productId && item.optionId === optionId)));
  };

  const clearCart = () => {
    setItems([]);
  };

  const totalItems = items.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <CartContext.Provider value={{ items, addToCart, removeFromCart, clearCart, totalItems }}>
      {children}
    </CartContext.Provider>
  );
};
